********
Eulerian
********

.. automodule:: networkx.algorithms.euler
.. autosummary::
   :toctree: generated/

   is_eulerian
   eulerian_circuit
